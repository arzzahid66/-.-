import sys
import os
import streamlit as st
import openai
from streamlit_chat import message
import google.generativeai as genai
import time  # Ifrom PIL import Image
from PIL import Image

# Set your OpenAI API key here
openai_key = st.secrets["OPENAI_API_KEY"]
st.title("Comparison Openai 3.5 turbo vs Gemini ai LLM")
st.subheader('By Abdul Rehman Zahid')
GOOGLE_API_KEY = "gemini api key "
genai.configure(api_key=GOOGLE_API_KEY)

model = genai.GenerativeModel("gemini-pro")
# Initialize a list to store search information in the session state
if 'search_history' not in st.session_state:
    st.session_state.search_history = []

prompt = st.text_input("Ask me anything ....")

search_button_gimini = st.button("Search from Gemini AI Pro")
search_button_openai = st.button("Search from OpenAI 3.5 Turbo")

if search_button_gimini:
    if prompt:
        try:
            start_time = time.time()
            response = model.generate_content(prompt)
            end_time = time.time()

            if response and response.text:
                st.write("Gimini AI Pro Response:")
                st.write(response.text)
                st.write(f"Time taken: {end_time - start_time:.2f} seconds")

                # Add search information to the history list in the session state
                st.session_state.search_history.append({
                    'model': 'Gimini AI Pro',
                    'prompt': prompt,
                    'response': response.text,
                    'time_taken': end_time - start_time
                })
            else:
                st.warning("Generated response from Gimini AI Pro is empty.")
        except IndexError:
            st.warning("The Gimini AI Pro model's response format is not as expected.")
        except Exception as e:
            st.error(f"An error occurred with Gimini AI Pro: {e}")
    else:
        st.warning("Please provide a prompt for Gimini AI Pro.")

if search_button_openai:
    if prompt:
        try:
            start_time = time.time()
            response = openai.Completion.create(
                model="gpt-3.5-turbo-instruct",
                prompt=prompt,
                max_tokens=150
            )
            end_time = time.time()

            if response and 'choices' in response and response['choices'][0]['text']:
                st.write("OpenAI 3.5 Turbo Response:")
                st.write(response['choices'][0]['text'])
                st.write(f"Time taken: {end_time - start_time:.2f} seconds")

                # Add search information to the history list in the session state
                st.session_state.search_history.append({
                    'model': 'OpenAI 3.5 Turbo',
                    'prompt': prompt,
                    'response': response['choices'][0]['text'],
                    'time_taken': end_time - start_time
                })
            else:
                st.warning("Generated response from OpenAI 3.5 Turbo is empty.")
        except Exception as e:
            st.error(f"An error occurred with OpenAI 3.5 Turbo: {e}")
    else:
        st.warning("Please provide a prompt for OpenAI 3.5 Turbo.")

# Display the last 5 searches in a table
st.write("\n\n### Last 5 Searches:")
if st.session_state.search_history:
    history_table = st.table(st.session_state.search_history[-5:])
else:
    st.info("No search history yet.")

# Add a button to clear the search history
clear_button = st.button("Clear History")
if clear_button:
    st.session_state.search_history = []  # Clear the search history
    st.success("Search history cleared.")

# Your Streamlit code for uploading an image
uploaded_file = st.file_uploader("Upload an image", type=["jpg", "jpeg", "png"])

if uploaded_file is not None:
    # Display the uploaded image
    image = Image.open(uploaded_file)
    st.image(image, caption="Uploaded Image", use_column_width=True)

    # Prompt for generating content
    prompt = st.text_area("Enter prompt for gemini-pro-vision model")

    if st.button("Generate Content"):
        # Check if both image and prompt are provided
        if image is not None and prompt:
            # Combine prompt and image for input to the model
            input_data = [prompt, image]

            # Process the combined input using gemini-pro-vision model
            model_vision = genai.GenerativeModel("gemini-pro-vision")
            response_vision = model_vision.generate_content(input_data)

            # Display the response
            st.write("Gemini Pro Vision Response:")
            st.write(response_vision.text)
        else:
            st.warning("Please provide both an image and a prompt.")


